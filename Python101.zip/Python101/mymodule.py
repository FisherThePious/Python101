def greeting(name):
    print "Hello, " + name 

person1 = {
  "name": "akshay",
  "age": 32,
  "country": "India"
} 
